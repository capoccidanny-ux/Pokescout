'use client';
import { useState, useRef } from 'react';

const cc = c => ({ NM:'#22d98a', LP:'#69f0ae', MP:'#f5c842', HP:'#ff9f1c', DMG:'#ff3366' }[c] || '#5a5a7a');
const gc = g => g>=9?'#22d98a':g>=7?'#f5c842':g>=5?'#ff9f1c':'#ff3366';

function getP(pd, cond) {
  if (!pd?.prices) return null;
  const p = pd.prices;
  return ({ NM: p.near_mint??p.normal, LP: p.lightly_played, MP: p.moderately_played, HP: p.heavily_played }[cond]) ?? p.market ?? p.normal ?? null;
}

export default function PokeScout() {
  const [mode, setModeState] = useState('convention');
  const [nego, setNego] = useState(85);
  const [wPrice, setWPrice] = useState('');
  const [imgSrc, setImgSrc] = useState(null);
  const [imgB64, setImgB64] = useState(null);
  const [imgType, setImgType] = useState('image/jpeg');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState('');
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const fileRef = useRef();
  const cameraRef = useRef();

  const loadFile = (file) => {
    if (!file) return;
    setImgType(file.type || 'image/jpeg');
    const r = new FileReader();
    r.onload = e => {
      setImgSrc(e.target.result);
      setImgB64(e.target.result.split(',')[1]);
      setResults(null);
      setError(null);
    };
    r.readAsDataURL(file);
  };

  const analyze = async () => {
    if (!imgB64) return;
    setLoading(true);
    setResults(null);
    setError(null);

    try {
      // Step 1: Identify cards
      setStep('🔍 Identification des cartes…');
      const scanRes = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: imgB64, mimeType: imgType })
      });
      const scanData = await scanRes.json();
      if (scanData.error) throw new Error(scanData.error);
      const cards = scanData.cards || [];
      if (!cards.length) throw new Error('Aucune carte détectée. Essaie une photo plus nette.');

      // Step 2: Get prices
      setStep('💰 Récupération des prix eBay…');
      const withPrices = await Promise.all(cards.map(async card => {
        const q = `${card.name} ${card.set}`;
        const res = await fetch(`/api/prices?q=${encodeURIComponent(q)}`);
        const pd = await res.json();
        return { ...card, priceData: pd };
      }));

      setStep('');
      setResults(withPrices);
    } catch(e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setStep('');
    }
  };

  const wp = mode === 'whatnot' ? parseFloat(wPrice) || null : null;
  let total = 0;
  (results||[]).forEach(c => { const p = getP(c.priceData, c.condition); if(p) total += p; });
  const offer = total * (nego/100);
  const isUnder = wp && total && wp < total * 0.9;
  const isOver = wp && total && wp > total * 1.1;

  return (
    <div style={{ maxWidth:520, margin:'0 auto', minHeight:'100vh', background:'#080810', color:'#eeeef5', fontFamily:'system-ui,sans-serif', paddingBottom:48 }}>
      <style>{`
        * { box-sizing:border-box; margin:0; padding:0; }
        input[type=range] { accent-color:#f5c842; width:100%; cursor:pointer; }
        input[type=number] { background:#16162a; border:1px solid #252540; border-radius:10px; padding:11px 14px; color:#eeeef5; font-size:15px; outline:none; width:100%; }
        input[type=number]:focus { border-color:#f5c842; }
        input::placeholder { color:#5a5a7a; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        a { text-decoration:none; }
      `}</style>

      {/* Header */}
      <div style={{ padding:'18px 20px 14px', display:'flex', alignItems:'center', justifyContent:'space-between', borderBottom:'1px solid #252540', background:'rgba(8,8,16,.95)', position:'sticky', top:0, zIndex:100 }}>
        <div style={{ fontWeight:900, fontSize:26, letterSpacing:3, color:'#f5c842' }}>POKE<span style={{color:'#eeeef5'}}>SCOUT</span></div>
        <div style={{ display:'flex', background:'#16162a', borderRadius:10, padding:3, gap:2 }}>
          {['convention','whatnot'].map(m => (
            <button key={m} onClick={() => setModeState(m)} style={{ padding:'5px 11px', border:'none', borderRadius:8, fontSize:11, fontWeight:700, cursor:'pointer', background: mode===m?'#f5c842':'transparent', color: mode===m?'#000':'#5a5a7a', transition:'all .2s' }}>
              {m==='convention'?'🎪 Convention':'📱 Whatnot'}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding:'0 20px' }}>

        {/* Camera / Upload */}
        <div style={{ marginTop:20 }}>
          {!imgSrc ? (
            <div style={{ border:'2px dashed #252540', borderRadius:16, padding:'32px 20px', textAlign:'center', cursor:'pointer', background:'#0f0f1a' }} onClick={() => cameraRef.current?.click()}>
              <div style={{ fontSize:44, marginBottom:12 }}>📷</div>
              <div style={{ fontWeight:800, fontSize:18, marginBottom:6 }}>Prends une photo</div>
              <div style={{ fontSize:13, color:'#5a5a7a' }}>Sleeves, top loaders & slabs OK</div>
              {/* Camera input - opens camera on mobile */}
              <input ref={cameraRef} type="file" accept="image/*" capture="environment" style={{ display:'none' }} onChange={e=>loadFile(e.target.files[0])} />
              {/* File input fallback */}
              <input ref={fileRef} type="file" accept="image/*" style={{ display:'none' }} onChange={e=>loadFile(e.target.files[0])} />
              <div style={{ marginTop:12, fontSize:11, color:'#5a5a7a', cursor:'pointer', textDecoration:'underline' }} onClick={e=>{ e.stopPropagation(); fileRef.current?.click(); }}>
                ou choisir depuis la galerie
              </div>
            </div>
          ) : (
            <div style={{ borderRadius:14, overflow:'hidden', position:'relative' }}>
              <img src={imgSrc} style={{ width:'100%', maxHeight:260, objectFit:'cover', display:'block' }} alt="" />
              <div style={{ position:'absolute', inset:0, background:'linear-gradient(to top,rgba(0,0,0,.85),transparent 60%)', display:'flex', alignItems:'flex-end', justifyContent:'space-between', padding:14 }}>
                <span style={{ fontSize:11, color:'rgba(255,255,255,.5)', cursor:'pointer', textDecoration:'underline' }} onClick={()=>{setImgSrc(null);setImgB64(null);setResults(null);}}>↺ Changer</span>
                <span style={{ fontSize:11, color:'rgba(255,255,255,.5)', cursor:'pointer', textDecoration:'underline' }} onClick={()=>cameraRef.current?.click()}>📷 Reprendre</span>
              </div>
            </div>
          )}
        </div>

        {/* Whatnot price */}
        {mode === 'whatnot' && (
          <div style={{ marginTop:14 }}>
            <div style={{ fontSize:10, fontWeight:700, color:'#5a5a7a', letterSpacing:1.5, textTransform:'uppercase', marginBottom:8 }}>Prix demandé dans le live ($)</div>
            <input type="number" placeholder="Ex: 8.00" value={wPrice} onChange={e=>setWPrice(e.target.value)} />
          </div>
        )}

        {/* Nego */}
        <div style={{ marginTop:14 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
            <div style={{ fontSize:10, fontWeight:700, color:'#5a5a7a', letterSpacing:1.5, textTransform:'uppercase' }}>Objectif de négociation</div>
            <div style={{ fontWeight:900, fontSize:24, color:'#f5c842' }}>{nego}%</div>
          </div>
          <input type="range" min={50} max={100} value={nego} onChange={e=>setNego(+e.target.value)} />
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:10, color:'#5a5a7a', marginTop:4 }}>
            <span>50% 🔥</span><span>100% prix plein</span>
          </div>
        </div>

        {/* Analyze button */}
        <button
          disabled={!imgB64 || loading}
          onClick={analyze}
          style={{ marginTop:16, width:'100%', padding:'15px', background: (!imgB64||loading)?'rgba(245,200,66,.4)':'#f5c842', color:'#000', border:'none', borderRadius:12, fontSize:18, fontWeight:900, letterSpacing:2, cursor: (!imgB64||loading)?'not-allowed':'pointer', transition:'all .2s' }}
        >
          {loading ? step || '⏳ Analyse…' : '⚡ ANALYSER LES CARTES'}
        </button>

        {error && (
          <div style={{ marginTop:12, padding:'12px 14px', background:'rgba(255,51,102,.1)', border:'1px solid rgba(255,51,102,.3)', borderRadius:10, fontSize:13, color:'#ff8aaa' }}>⚠️ {error}</div>
        )}

        {/* Results */}
        {results && (
          <div style={{ marginTop:16, display:'flex', flexDirection:'column', gap:12 }}>

            {/* Lot summary */}
            <div style={{ background:'#16162a', borderRadius:16, padding:18, border:'1px solid #252540', animation:'fadeUp .3s ease' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:14 }}>
                <div>
                  <div style={{ fontSize:10, fontWeight:700, color:'#5a5a7a', letterSpacing:1.5, textTransform:'uppercase', marginBottom:4 }}>Valeur totale</div>
                  <div style={{ fontWeight:900, fontSize:40, color:'#f5c842', lineHeight:1 }}>${total.toFixed(2)}</div>
                  <div style={{ fontSize:12, color:'#5a5a7a', marginTop:3 }}>{results.length} carte{results.length>1?'s':''}</div>
                </div>
                {isUnder && <div style={{ background:'rgba(34,217,138,.12)', border:'1px solid rgba(34,217,138,.4)', color:'#22d98a', borderRadius:10, padding:'10px 12px', fontSize:12, fontWeight:700, textAlign:'center' }}>🔥 DEAL!<br/>{Math.round((1-wp/total)*100)}% sous valeur</div>}
                {isOver && <div style={{ background:'rgba(255,51,102,.12)', border:'1px solid rgba(255,51,102,.4)', color:'#ff3366', borderRadius:10, padding:'10px 12px', fontSize:12, fontWeight:700, textAlign:'center' }}>⚠️ TROP CHER<br/>+{Math.round((wp/total-1)*100)}%</div>}
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                <div style={{ background:'#0f0f1a', borderRadius:10, padding:'10px 12px' }}>
                  <div style={{ fontSize:10, color:'#5a5a7a', marginBottom:4, fontWeight:600 }}>Offrir max ({nego}%)</div>
                  <div style={{ fontSize:18, fontWeight:700, color:'#f5c842' }}>${offer.toFixed(2)}</div>
                </div>
                {wp
                  ? <div style={{ background:'#0f0f1a', borderRadius:10, padding:'10px 12px' }}>
                      <div style={{ fontSize:10, color:'#5a5a7a', marginBottom:4, fontWeight:600 }}>Prix live</div>
                      <div style={{ fontSize:18, fontWeight:700, color: isUnder?'#22d98a':isOver?'#ff3366':'#eeeef5' }}>${wp.toFixed(2)}</div>
                    </div>
                  : <div style={{ background:'#0f0f1a', borderRadius:10, padding:'10px 12px' }}>
                      <div style={{ fontSize:10, color:'#5a5a7a', marginBottom:4, fontWeight:600 }}>Tu économises</div>
                      <div style={{ fontSize:18, fontWeight:700, color:'#22d98a' }}>-${(total-offer).toFixed(2)}</div>
                    </div>
                }
              </div>
            </div>

            {/* Individual cards */}
            {results.map((card, i) => {
              const price = getP(card.priceData, card.condition);
              const nm = getP(card.priceData,'NM'), lp = getP(card.priceData,'LP'), mp = getP(card.priceData,'MP');
              const col = cc(card.condition);
              const gradeCol = gc(card.psa_estimate||7);
              const probs = card.psa_probs || {"10":3,"9":15,"8":30,"7":35,"6":17};
              const mavin = `https://mavin.io/search?q=${encodeURIComponent(card.name+' '+card.set)}`;
              const ebay = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(card.name+' '+card.set)}&LH_Sold=1&LH_Complete=1`;

              return (
                <div key={i} style={{ background:'#0f0f1a', borderRadius:16, padding:16, border:'1px solid #252540', animation:`fadeUp .3s ease ${i*.1}s both` }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
                    <div>
                      <div style={{ fontWeight:800, fontSize:17 }}>{card.name}</div>
                      <div style={{ fontSize:11, color:'#5a5a7a', marginTop:3 }}>{card.set}{card.number?' · #'+card.number:''}</div>
                    </div>
                    <div style={{ textAlign:'right' }}>
                      <div style={{ fontWeight:900, fontSize:26, color:'#f5c842', lineHeight:1 }}>{price?'$'+price.toFixed(2):'N/A'}</div>
                      <div style={{ fontSize:10, color:'#5a5a7a', marginTop:2 }}>eBay · {card.condition}</div>
                    </div>
                  </div>

                  {/* Badges */}
                  <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:12 }}>
                    <span style={{ padding:'4px 10px', borderRadius:20, fontSize:10, fontWeight:700, border:`1px solid ${col}`, color:col, background:col+'20' }}>{card.condition_fr||card.condition}</span>
                    {card.in_slab
                      ? <span style={{ padding:'4px 10px', borderRadius:20, fontSize:10, fontWeight:700, border:'1px solid #f5c842', color:'#f5c842', background:'rgba(245,200,66,.15)' }}>🏆 Slab {card.slab_grade}</span>
                      : <span style={{ padding:'4px 10px', borderRadius:20, fontSize:10, fontWeight:700, border:`1px solid ${gradeCol}`, color:gradeCol, background:gradeCol+'20' }}>PSA ~{card.psa_estimate||7}</span>
                    }
                  </div>

                  {/* Price grid */}
                  <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:6, marginBottom:12 }}>
                    {[['NM',nm,'#22d98a'],['LP',lp,'#f5c842'],['MP',mp,'#ff9f1c']].map(([l,v,c])=>(
                      <div key={l} style={{ background:'#16162a', borderRadius:10, padding:9, textAlign:'center' }}>
                        <div style={{ fontSize:9, color:'#5a5a7a', marginBottom:3, fontWeight:600 }}>{l}</div>
                        <div style={{ fontSize:14, fontWeight:700, color:c }}>{v?'$'+v.toFixed(2):'—'}</div>
                      </div>
                    ))}
                  </div>

                  {/* Links */}
                  <div style={{ display:'flex', gap:8, marginBottom:12 }}>
                    <a href={mavin} target="_blank" style={{ flex:1, padding:10, border:'1px solid #252540', borderRadius:10, color:'#5a5a7a', fontSize:12, fontWeight:600, textAlign:'center', display:'block' }}>📊 Mavin →</a>
                    <a href={ebay} target="_blank" style={{ flex:1, padding:10, border:'1px solid #252540', borderRadius:10, color:'#5a5a7a', fontSize:12, fontWeight:600, textAlign:'center', display:'block' }}>🛒 eBay sold →</a>
                  </div>

                  {/* PSA grade bars */}
                  {!card.in_slab && (
                    <div>
                      <div style={{ fontSize:10, color:'#5a5a7a', fontWeight:700, letterSpacing:1, textTransform:'uppercase', marginBottom:8 }}>Probabilité grade PSA</div>
                      <div style={{ display:'flex', gap:5 }}>
                        {[10,9,8,7,6].map(g => {
                          const pct = probs[g]||probs[String(g)]||0, c2=gc(g);
                          return (
                            <div key={g} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:3 }}>
                              <div style={{ width:'100%', height:44, background:'#16162a', borderRadius:5, overflow:'hidden', display:'flex', alignItems:'flex-end' }}>
                                <div style={{ width:'100%', height:`${pct}%`, background:c2, opacity:.9, borderRadius:5 }}/>
                              </div>
                              <div style={{ fontWeight:700, fontSize:14, color:c2 }}>{g}</div>
                              <div style={{ fontSize:9, color:'#5a5a7a' }}>{pct}%</div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            <button onClick={()=>{setImgSrc(null);setImgB64(null);setResults(null);setError(null);}} style={{ padding:12, background:'transparent', color:'#5a5a7a', border:'1px solid #252540', borderRadius:12, fontSize:13, cursor:'pointer', width:'100%' }}>
              ↩ Scanner d'autres cartes
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
