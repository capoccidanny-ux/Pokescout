# PokeScout 🎯

Scanner de cartes Pokémon autonome — photo → identification IA → prix eBay.

## Déploiement sur Vercel (5 minutes)

### Étape 1 — Uploade sur GitHub
1. Va sur github.com → New repository
2. Nomme-le `pokescout`
3. Uploade tous ces fichiers

### Étape 2 — Déploie sur Vercel
1. Va sur vercel.com → New Project
2. Connecte ton repo GitHub `pokescout`
3. Clique Deploy

### Étape 3 — Ajoute tes clés API
Dans Vercel → Settings → Environment Variables, ajoute :

```
GEMINI_API_KEY = AIzaSyBEzcGnXq13g55M6kbt9hDAylRb62yE4O0
POKE_API_KEY = pokeprice_free_2295db00d989b588751b2c5b3fcab9192b4a1d862790180d
```

### Étape 4 — Redéploie
Vercel → Deployments → Redeploy

C'est tout ! Ton app est live sur une URL pokescout.vercel.app 🚀
